/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import  java.awt.*;
import java.awt.event.*;
import java.awt.Polygon;
import java.util.ArrayList;
import javax.swing.Timer;
import java.applet.AudioClip;
import java.util.Random;

/**
 *
 * @author RealProgramming4Kids
 */
public class Asteroids extends Applet implements KeyListener, ActionListener { 

    SpaceCraft ship;
    Timer timer;
    Image offscreen;
    Graphics offg;
    SpaceRock rock;
    ArrayList<SpaceRock> asteroidList;
    ArrayList<Bullet> bulletList;
    ArrayList<AlienShip> alienList;
    ArrayList<Debris> explosionList;
    public static ArrayList<Bullet> alienBulletList;
    boolean upKey, leftKey, rightKey, downKey, spaceKey, WKey, AKey, SKey, DKey;
    boolean emptyAsteroids;
    AudioClip shipLaser, alienLaser, shipHit, asteroidHit, alienHit, thruster;
    
    public void init() {
        this.setSize(900, 600);
        this.addKeyListener(this);
        ship = new SpaceCraft();
        timer = new Timer(20, this);
        offscreen = createImage(this.getWidth(), this.getHeight());
        offg = offscreen.getGraphics();
        asteroidList = new ArrayList();
        alienList = new ArrayList();
        explosionList = new ArrayList();
        for (int i = 0; i < 3; i ++) {                                               // 4
            asteroidList.add(new SpaceRock());
        }
        bulletList = new ArrayList();
        alienBulletList = new ArrayList();
        emptyAsteroids = false;
        shipLaser = getAudioClip(getCodeBase(), "Pulse2.wav");
        alienLaser = getAudioClip(getCodeBase(), "Pulse.wav");
        shipHit = getAudioClip(getCodeBase(), "ExplosionShip.wav");
        asteroidHit = getAudioClip(getCodeBase(), "ExplosionAsteroid.wav");
        alienHit = getAudioClip(getCodeBase(), "ExplosionAlien.wav");
        thruster = getAudioClip(getCodeBase(), "Thruster.wav");
    }
    
    public void paint(Graphics g){
        offg.setColor(Color.BLACK);
        offg.fillRect(0, 0, 900, 600);
        offg.setColor(Color.yellow);
        
        if (ship.Active == true) {
            ship.paint(offg);
        }
        for (int i = 0; i < asteroidList.size(); i ++) {
            asteroidList.get(i).paint(offg);
        }
        for (int i = 0; i < bulletList.size(); i ++) {
            bulletList.get(i).paint(offg);
        }
        for (int i = 0; i < alienList.size(); i ++) {
            alienList.get(i).paint(offg);
            }
        for (int i = 0; i < alienBulletList.size(); i ++) {
            alienBulletList.get(i).paint(offg);
            
        }
        for (int i = 0; i < explosionList.size(); i ++) {
            explosionList.get(i).paint(offg);
        }
        
        if (asteroidList.isEmpty() && emptyAsteroids == false) {
            emptyAsteroids = true;
            spawnAliens();
        }
        
        if (asteroidList.isEmpty() == true && alienList.isEmpty() == true) {
            offg.drawString("Game Over - Victory !!!", 400, 300);
            alienLaser.stop();
        }
        offg.drawString("Lives: " + ship.lives, 0, 15);
        if (ship.lives <= 0) {
            offg.drawString("Game Over - You Lost !!!", 400, 300);
        }
        offg.drawString("Score: " + ship.score, 820, 15);
        
        g.drawImage(offscreen, 0, 0, this);
        repaint();
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            rightKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            leftKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            upKey = true;
            thruster.loop();
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            downKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            spaceKey = true;
        }
        
        if (e.getKeyCode() == KeyEvent.VK_D) {
            DKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_A) {
            AKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_W) {
            WKey = true;
            thruster.loop();
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
            SKey = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_P) {
            asteroidList.clear();
        }
    }
    
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            rightKey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            leftKey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            upKey = false;
            thruster.stop();
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            downKey = false;
            thruster.stop();
        }
        if (e.getKeyCode() == KeyEvent.VK_D) {
            DKey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_A) {
            AKey = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_W) {
            WKey = false;
            thruster.stop();
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
            SKey = false;
            thruster.stop();
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            spaceKey = false;
        }
    }
    
    public void keyTyped(KeyEvent e) {
        
    }
    
    public void keyCheck() {
        if (upKey) {
            ship.accelerate();
        }
        if (leftKey) {
            ship.rotateLeft();
        }
        if (rightKey) {
            ship.rotateRight();
        }
        if (downKey) {
            ship.slow();
        }
        if (WKey) {
            ship.accelerate();
        }
        if (AKey) {
            ship.rotateLeft();
        }
        if (DKey) {
            ship.rotateRight();
        }
        if (SKey) {
            ship.slow();
        }
        if (spaceKey) {
            fireBullet();
        }
    }
    
    public void update(Graphics g){
        paint(g);
    }

    public void actionPerformed(ActionEvent e) {
        keyCheck();
        respawnShip();
        ship.updatePosition();
        for (int i = 0; i < asteroidList.size(); i++){
            asteroidList.get(i).updatePosition();
        }
        for (int i = 0; i < bulletList.size(); i++){
            bulletList.get(i).updatePosition();
            if (bulletList.get(i).counter == 60 || bulletList.get(i).Active == false) {
                bulletList.remove(i);
            }
        }
        for (int i = 0; i < alienList.size(); i++) {
            alienList.get(i).updatePosition();
        }
        for (int i = 0; i < alienBulletList.size(); i++) {
            alienLaser.loop();
            alienBulletList.get(i).updatePosition();
            
            if (alienBulletList.get(i).counter == 27 || alienBulletList.get(i).Active == false) {                           //27
                alienBulletList.remove(i);
            }
        }
        for (int i = 0; i < explosionList.size(); i++) {
            explosionList.get(i).updatePosition();
            if (explosionList.get(i).counter == 10) {
                explosionList.remove(i);
            }
        }
        
        checkAsteroidCollision();
        checkAsteroidDestruction();
        checkAlienCollision();
        checkAlienDestruction();
    }
    
    public void start() {
        timer.start();
    }
    
    public void stop() {
        timer.stop();
    }
    
    public boolean collision(VectorSprite thing1, VectorSprite thing2) {
        int x, y;
        for (int i = 0; i < thing1.drawShape.npoints; i++) {
            x = thing1.drawShape.xpoints[i];
            y = thing1.drawShape.ypoints[i];
        
            if (thing2.drawShape.contains(x, y)) {
                return true;
            }
        }
        for (int i = 0; i < thing2.drawShape.npoints; i++) {
            x = thing2.drawShape.xpoints[i];
            y = thing2.drawShape.ypoints[i];
        
            if (thing1.drawShape.contains(x, y)) {
                return true;
            }
        }
        return false;
    }
    
    public void checkAsteroidCollision() {
        
        double rand;
        
        for (int i = 0; i < asteroidList.size(); i ++) {
            if (collision(ship, asteroidList.get(i)) == true && ship.Active == true) {
                ship.hit();
                shipHit.play();
                rand = Math.random() * 5 + 5;
                for (int k = 0; k < rand; k ++) {
                    explosionList.add(new Debris(ship.xposition, ship.yposition));
                }
            }
            for (int j = 0; j < bulletList.size(); j ++) {
                if (collision(bulletList.get(j), asteroidList.get(i))) {
                    bulletList.get(j).Active = false;
                    asteroidList.get(i).Active = false;
                    asteroidHit.play();
                    rand = Math.random() * 5 + 5;
                    for (int k = 0; k < rand; k ++) {
                        explosionList.add(new Debris(asteroidList.get(i).xposition, asteroidList.get(i).yposition));
                    }
                }
            }
        }
    }
    
    public void checkAlienCollision() {
        
        double rand;
        
        for (int i = 0; i < alienList.size(); i ++) {
            if (collision(ship, alienList.get(i)) == true && ship.Active == true) {
                ship.hit();
                shipHit.play();
                rand = Math.random() * 5 + 5;
                for (int k = 0; k < rand; k ++) {
                    explosionList.add(new Debris(ship.xposition, ship.yposition));
                }
            }
            for (int j = 0; j < bulletList.size(); j ++) {
                if (collision(bulletList.get(j), alienList.get(i))) {
                    bulletList.get(j).Active = false; 
                    alienList.get(i).Active = false;
                    alienHit.play();
                    rand = Math.random() * 5 + 5;
                    for (int k = 0; k < rand; k ++) {
                        explosionList.add(new Debris(alienList.get(i).xposition, alienList.get(i).yposition));
                    }
                }
            }
            for (int g = 0; g < alienBulletList.size(); g ++) {
                if (collision(ship, alienBulletList.get(g)) && ship.Active == true) {
                    ship.hit();
                    rand = Math.random() * 5 + 5;
                    for (int k = 0; k < rand; k ++) {
                        explosionList.add(new Debris(ship.xposition, ship.yposition));
                    }
                }
            }
        }
    }
    
    public void respawnShip() {
        if (ship.Active == false && ship.counter > 50 && isRespawnSafe() == true && ship.lives > 0) {
            ship.reset();
        }
    }
    
    public boolean isRespawnSafe() {
        double x, y, h;
        for (int i = 0; i < asteroidList.size(); i++) {
            x = asteroidList.get(i).xposition - 450;
            y = asteroidList.get(i).yposition - 300;
            h = Math.sqrt(x * x + y * y);
            if (h < 75) {
                return false;
            }
        }
        for (int i = 0; i < alienList.size(); i++) {
            x = alienList.get(i).xposition - 450;
            y = alienList.get(i).yposition - 300;
            h = Math.sqrt(x * x + y * y);
            if (h < 75) {
                return false;
            }
        }
        return true;
    }
    
    public void fireBullet() {
        
        if (ship.counter > 4 && ship.Active == true){
            double rand1;
            rand1 = Math.random();
            double rand2;
            rand2 = Math.random();
            //bulletList.add(new Bullet(ship.xposition, ship.yposition, ship.angle));
            bulletList.add(new Bullet(ship.xposition - 0.3, ship.yposition - 0.3, ship.angle- rand1/3.5));
            bulletList.add(new Bullet(ship.xposition + 0.3, ship.yposition + 0.3, ship.angle+ rand2/3.5));
            ship.counter = 0;
            shipLaser.play();
        }   
    }
    
    public void checkAsteroidDestruction() {
        for (int i = 0; i < asteroidList.size(); i++){
            if (asteroidList.get(i).Active == false) {
                if (asteroidList.get(i).size > 1) {
                    asteroidList.add(new SpaceRock(asteroidList.get(i).xposition + 15, asteroidList.get(i).yposition + 15, asteroidList.get(i).size - 1));
                    asteroidList.add(new SpaceRock(asteroidList.get(i).xposition - 15, asteroidList.get(i).yposition - 15, asteroidList.get(i).size - 1));
                    ship.score += 20;
                }
                asteroidList.remove(i);
            }
        }
    }
    
    public void checkAlienDestruction() {
        for (int i = 0; i < alienList.size(); i++){
            if (alienList.get(i).Active == false) {
                if (alienList.get(i).Active == false) {
                    ship.score += 50;
                }
                alienList.remove(i);
            }
        }
    }
    

    public void spawnAliens(){
        if (emptyAsteroids == true){
            for (int i = 0; i < 3; i ++) {                                               // 4
                alienList.add(new AlienShip());
            }
        }
    }
}
