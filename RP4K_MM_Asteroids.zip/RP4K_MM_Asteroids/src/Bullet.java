import java.awt.Polygon;

/**
 *
 * @author RealProgramming4Kids
 */
public class Bullet extends VectorSprite {
    
    public Bullet(double x, double y, double a) {
        shape = new Polygon();
        shape.addPoint(0, 0);
        shape.addPoint(0, 0);
        shape.addPoint(0, 0);
        shape.addPoint(0, 0);
        drawShape = new Polygon();
        drawShape.addPoint(0, 0);
        drawShape.addPoint(0, 0);
        drawShape.addPoint(0, 0);
        drawShape.addPoint(0, 0);
        xposition = x;
        yposition = y;
        angle = a;
        thrust = 10;
        xspeed = Math.cos(angle) * thrust;
        yspeed = Math.sin(angle) * thrust;
        Active = true;
    }
    
}
