import java.awt.Polygon;

/**
 *
 * @author RealProgramming4Kids
 */
public class AlienShip extends VectorSprite {
    
    int size;
    
    public AlienShip() {
        size = 2;
        InitializeAlien();
        
    }
    
    public void InitializeAlien() {
        
        shape = new Polygon();
        shape.addPoint(20, 0);
        shape.addPoint(0, 15);
        shape.addPoint(-15, 0);
        shape.addPoint(0, -15);
        
        drawShape = new Polygon();
        drawShape.addPoint(20, 0);
        drawShape.addPoint(0, 15);
        drawShape.addPoint(-15, 0);
        drawShape.addPoint(0, -15);
        
        rotation = 0.1;
        
        double h, a;
        h = Math.random() + 1;
        a = Math.random() * 2 * Math.PI;
        xspeed = Math.cos(a) * h;
        yspeed = Math.sin(a) * h;
        
        double m, n;
        m = Math.random() * 400 + 100;
        n = Math.random() * 2 * Math.PI;
        xposition = Math.cos(n) * m + 450;
        yposition = Math.sin(n) * m + 300;
        
        Active = true;
    }
    
    public void updatePosition() {
        angle += rotation;
        super.updatePosition();
        
        if (Math.random() > 0.9) {
            Asteroids.alienBulletList.add(new Bullet(xposition, yposition, angle));
            
        }
    }
}
