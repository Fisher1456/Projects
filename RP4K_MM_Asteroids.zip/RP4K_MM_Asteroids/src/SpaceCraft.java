
import java.awt.Polygon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RealProgramming4Kids
 */
public class SpaceCraft extends VectorSprite {
    
    int lives;
    int score;
    
    public SpaceCraft() {
        shape = new Polygon();
        shape.addPoint(15, 0);
        shape.addPoint(-10, 10);
        shape.addPoint(-10, -10);
        drawShape = new Polygon();
        drawShape.addPoint(15, 0);
        drawShape.addPoint(-10, 10);
        drawShape.addPoint(-10, -10);
        xposition = 450;
        yposition = 300;
        rotation = 0.2;
        thrust = 0.75;
        Active = true;
        lives = 4;
        score = 0;
    }
    
    public void accelerate() {
        xspeed += Math.cos(angle) * thrust;
        yspeed += Math.sin(angle) * thrust;
    }
    
    public void rotateLeft() {
        angle -= rotation;
    }
    
    public void rotateRight() {
        angle += rotation;
    }
    
    public void slow() {
        xspeed = 0;
        yspeed = 0;
    }
    
    public void hit() {
        lives--;
        score -= 15;
        Active = false;
        counter = 0;
    }
    
    public void reset() {
        xposition = 450;
        yposition = 300;
        xspeed = 0;
        yspeed = 0;
        angle = -Math.PI / 2;
        Active = true;
    }
}
